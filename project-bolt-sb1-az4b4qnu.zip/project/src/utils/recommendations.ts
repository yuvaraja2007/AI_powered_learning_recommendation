import { Course, User, UserCourseProgress } from '../types';

export function calculateCosineSimilarity(vec1: number[], vec2: number[]): number {
  const dotProduct = vec1.reduce((sum, val, i) => sum + val * vec2[i], 0);
  const mag1 = Math.sqrt(vec1.reduce((sum, val) => sum + val * val, 0));
  const mag2 = Math.sqrt(vec2.reduce((sum, val) => sum + val * val, 0));
  return dotProduct / (mag1 * mag2) || 0;
}

export function getRecommendedCourses(
  user: User,
  allCourses: Course[],
  userProgress: UserCourseProgress[]
): Course[] {
  const completedCourseIds = new Set(
    userProgress.filter(p => p.status === 'completed').map(p => p.courseId)
  );

  const filteredCourses = allCourses.filter(course => {
    if (completedCourseIds.has(course.id)) return false;

    if (user.learningBudget === 'free' && course.priceType === 'paid') return false;
    if (user.learningBudget === 'paid' && course.priceType === 'free') return false;

    if (user.preferredPlatforms.length > 0 &&
        !user.preferredPlatforms.includes(course.platform)) {
      return false;
    }

    return true;
  });

  const scoredCourses = filteredCourses.map(course => {
    let score = 0;

    if (user.skillInterests.includes(course.skill)) {
      score += 50;
    }

    const userSkillLevel = user.skillLevels[course.skill];
    if (userSkillLevel === 'beginner' && course.difficultyLevel === 'beginner') {
      score += 30;
    } else if (userSkillLevel === 'intermediate' &&
               (course.difficultyLevel === 'intermediate' || course.difficultyLevel === 'beginner')) {
      score += 25;
    } else if (userSkillLevel === 'advanced' && course.difficultyLevel === 'advanced') {
      score += 30;
    }

    score += course.rating * 5;

    if (course.priceType === 'free') {
      score += 10;
    }

    return { course, score };
  });

  scoredCourses.sort((a, b) => b.score - a.score);

  return scoredCourses.slice(0, 10).map(item => item.course);
}

export function generateWeeklyPlan(
  user: User,
  recommendedCourses: Course[]
): {
  courses: Course[];
  totalHours: number;
  goals: string[];
} {
  const selectedCourses: Course[] = [];
  let totalHours = 0;
  const targetHours = user.weeklyGoalHours;

  for (const course of recommendedCourses) {
    if (totalHours + course.durationHours <= targetHours * 1.2) {
      selectedCourses.push(course);
      totalHours += course.durationHours;
    }
    if (selectedCourses.length >= 3) break;
  }

  const goals = [
    `Complete ${selectedCourses.length} courses this week`,
    `Spend ${targetHours} hours learning`,
    `Improve skills in ${user.skillInterests.slice(0, 2).join(' and ')}`
  ];

  return { courses: selectedCourses, totalHours, goals };
}

export function analyzeSkillGaps(
  user: User,
  allCourses: Course[],
  userProgress: UserCourseProgress[]
): { skill: string; level: string; suggestedCourses: Course[] }[] {
  const skillGaps: { skill: string; level: string; suggestedCourses: Course[] }[] = [];

  for (const skill of user.skillInterests) {
    const currentLevel = user.skillLevels[skill] || 'beginner';
    let nextLevel = currentLevel;

    if (currentLevel === 'beginner') nextLevel = 'intermediate';
    else if (currentLevel === 'intermediate') nextLevel = 'advanced';

    const suggestedCourses = allCourses
      .filter(c => c.skill === skill && c.difficultyLevel === nextLevel)
      .sort((a, b) => b.rating - a.rating)
      .slice(0, 3);

    if (suggestedCourses.length > 0) {
      skillGaps.push({ skill, level: nextLevel, suggestedCourses });
    }
  }

  return skillGaps;
}

export function getTrendingCourses(
  courses: Course[],
  userProgress: UserCourseProgress[]
): Course[] {
  const courseEnrollments = new Map<string, number>();

  userProgress.forEach(progress => {
    const count = courseEnrollments.get(progress.courseId) || 0;
    courseEnrollments.set(progress.courseId, count + 1);
  });

  const scoredCourses = courses.map(course => {
    const enrollments = courseEnrollments.get(course.id) || 0;
    const score = course.rating * 10 + enrollments * 5;
    return { course, score };
  });

  scoredCourses.sort((a, b) => b.score - a.score);

  return scoredCourses.slice(0, 8).map(item => item.course);
}
