import { Course, Test, Badge, Question } from '../types';

export const SKILLS = [
  'Python', 'JavaScript', 'React', 'Data Science', 'Machine Learning',
  'Web Development', 'Mobile Development', 'DevOps', 'Cloud Computing',
  'Cybersecurity', 'UI/UX Design', 'SQL', 'Java', 'C++', 'Digital Marketing'
];

export const PLATFORMS = ['YouTube', 'Udemy', 'Coursera', 'edX', 'freeCodeCamp', 'Khan Academy', 'Pluralsight', 'LinkedIn Learning'];

export const mockCourses: Course[] = [
  {
    id: '1',
    title: 'Complete Python Bootcamp: Go from Zero to Hero',
    skill: 'Python',
    description: 'Learn Python like a Professional! Start from the basics and go all the way to creating your own applications.',
    platform: 'Udemy',
    priceType: 'paid',
    priceAmount: 84.99,
    url: 'https://www.udemy.com/course/complete-python-bootcamp/',
    difficultyLevel: 'beginner',
    durationHours: 22,
    rating: 4.6,
    thumbnailUrl: 'https://images.pexels.com/photos/1181671/pexels-photo-1181671.jpeg',
    tags: ['programming', 'backend', 'scripting']
  },
  {
    id: '2',
    title: 'Python Tutorial for Beginners',
    skill: 'Python',
    description: 'Learn Python programming from scratch with this comprehensive free tutorial series.',
    platform: 'YouTube',
    priceType: 'free',
    priceAmount: 0,
    url: 'https://www.youtube.com/watch?v=_uQrJ0TkZlc',
    difficultyLevel: 'beginner',
    durationHours: 6,
    rating: 4.8,
    thumbnailUrl: 'https://images.pexels.com/photos/577585/pexels-photo-577585.jpeg',
    tags: ['programming', 'tutorial', 'basics']
  },
  {
    id: '3',
    title: 'React - The Complete Guide 2024',
    skill: 'React',
    description: 'Dive in and learn React from scratch! Learn React, Hooks, Redux, React Router, Next.js, Best Practices and more!',
    platform: 'Udemy',
    priceType: 'paid',
    priceAmount: 94.99,
    url: 'https://www.udemy.com/course/react-the-complete-guide/',
    difficultyLevel: 'intermediate',
    durationHours: 40,
    rating: 4.7,
    thumbnailUrl: 'https://images.pexels.com/photos/11035471/pexels-photo-11035471.jpeg',
    tags: ['frontend', 'javascript', 'web development']
  },
  {
    id: '4',
    title: 'React JS Full Course',
    skill: 'React',
    description: 'Complete React course covering fundamentals, hooks, and modern practices - completely free!',
    platform: 'YouTube',
    priceType: 'free',
    priceAmount: 0,
    url: 'https://www.youtube.com/watch?v=bMknfKXIFA8',
    difficultyLevel: 'beginner',
    durationHours: 12,
    rating: 4.9,
    thumbnailUrl: 'https://images.pexels.com/photos/270348/pexels-photo-270348.jpeg',
    tags: ['frontend', 'javascript', 'web development']
  },
  {
    id: '5',
    title: 'Machine Learning Specialization',
    skill: 'Machine Learning',
    description: 'Master fundamental AI concepts and develop practical machine learning skills.',
    platform: 'Coursera',
    priceType: 'paid',
    priceAmount: 49.99,
    url: 'https://www.coursera.org/specializations/machine-learning-introduction',
    difficultyLevel: 'intermediate',
    durationHours: 80,
    rating: 4.9,
    thumbnailUrl: 'https://images.pexels.com/photos/8386440/pexels-photo-8386440.jpeg',
    tags: ['ai', 'ml', 'algorithms']
  },
  {
    id: '6',
    title: 'Machine Learning Course - CS229',
    skill: 'Machine Learning',
    description: 'Stanford\'s famous machine learning course taught by Andrew Ng, available free on YouTube.',
    platform: 'YouTube',
    priceType: 'free',
    priceAmount: 0,
    url: 'https://www.youtube.com/watch?v=jGwO_UgTS7I',
    difficultyLevel: 'advanced',
    durationHours: 30,
    rating: 4.8,
    thumbnailUrl: 'https://images.pexels.com/photos/8386434/pexels-photo-8386434.jpeg',
    tags: ['ai', 'ml', 'stanford']
  },
  {
    id: '7',
    title: 'The Complete JavaScript Course 2024',
    skill: 'JavaScript',
    description: 'The modern JavaScript course for everyone! Master JavaScript with projects, challenges and theory.',
    platform: 'Udemy',
    priceType: 'paid',
    priceAmount: 84.99,
    url: 'https://www.udemy.com/course/the-complete-javascript-course/',
    difficultyLevel: 'beginner',
    durationHours: 69,
    rating: 4.7,
    thumbnailUrl: 'https://images.pexels.com/photos/4164418/pexels-photo-4164418.jpeg',
    tags: ['programming', 'frontend', 'web']
  },
  {
    id: '8',
    title: 'JavaScript Programming - Full Course',
    skill: 'JavaScript',
    description: 'Learn JavaScript from scratch with this free comprehensive course covering all fundamentals.',
    platform: 'freeCodeCamp',
    priceType: 'free',
    priceAmount: 0,
    url: 'https://www.freecodecamp.org/learn/javascript-algorithms-and-data-structures/',
    difficultyLevel: 'beginner',
    durationHours: 10,
    rating: 4.8,
    thumbnailUrl: 'https://images.pexels.com/photos/546819/pexels-photo-546819.jpeg',
    tags: ['programming', 'frontend', 'basics']
  },
  {
    id: '9',
    title: 'Data Science Professional Certificate',
    skill: 'Data Science',
    description: 'Launch your career in data science. Learn in-demand skills like Python, SQL, and machine learning.',
    platform: 'Coursera',
    priceType: 'paid',
    priceAmount: 39.99,
    url: 'https://www.coursera.org/professional-certificates/ibm-data-science',
    difficultyLevel: 'intermediate',
    durationHours: 120,
    rating: 4.6,
    thumbnailUrl: 'https://images.pexels.com/photos/7947661/pexels-photo-7947661.jpeg',
    tags: ['data', 'analytics', 'python']
  },
  {
    id: '10',
    title: 'Data Science Tutorial for Beginners',
    skill: 'Data Science',
    description: 'Free comprehensive introduction to data science, covering Python, statistics, and data visualization.',
    platform: 'YouTube',
    priceType: 'free',
    priceAmount: 0,
    url: 'https://www.youtube.com/watch?v=ua-CiDNNj30',
    difficultyLevel: 'beginner',
    durationHours: 8,
    rating: 4.7,
    thumbnailUrl: 'https://images.pexels.com/photos/6801648/pexels-photo-6801648.jpeg',
    tags: ['data', 'analytics', 'visualization']
  },
  {
    id: '11',
    title: 'Web Development Bootcamp',
    skill: 'Web Development',
    description: 'The only course you need to learn web development - HTML, CSS, JS, Node, and more!',
    platform: 'Udemy',
    priceType: 'paid',
    priceAmount: 89.99,
    url: 'https://www.udemy.com/course/the-web-developer-bootcamp/',
    difficultyLevel: 'beginner',
    durationHours: 63,
    rating: 4.7,
    thumbnailUrl: 'https://images.pexels.com/photos/1181244/pexels-photo-1181244.jpeg',
    tags: ['html', 'css', 'javascript', 'fullstack']
  },
  {
    id: '12',
    title: 'Full Stack Web Development Course',
    skill: 'Web Development',
    description: 'Learn web development for free with HTML, CSS, JavaScript, React, Node.js and more.',
    platform: 'freeCodeCamp',
    priceType: 'free',
    priceAmount: 0,
    url: 'https://www.freecodecamp.org/learn/',
    difficultyLevel: 'beginner',
    durationHours: 15,
    rating: 4.9,
    thumbnailUrl: 'https://images.pexels.com/photos/1181271/pexels-photo-1181271.jpeg',
    tags: ['html', 'css', 'javascript', 'fullstack']
  },
  {
    id: '13',
    title: 'AWS Certified Solutions Architect',
    skill: 'Cloud Computing',
    description: 'Pass the AWS Certified Solutions Architect Associate exam with this comprehensive course.',
    platform: 'Udemy',
    priceType: 'paid',
    priceAmount: 94.99,
    url: 'https://www.udemy.com/course/aws-certified-solutions-architect-associate/',
    difficultyLevel: 'intermediate',
    durationHours: 27,
    rating: 4.7,
    thumbnailUrl: 'https://images.pexels.com/photos/1181354/pexels-photo-1181354.jpeg',
    tags: ['aws', 'cloud', 'devops']
  },
  {
    id: '14',
    title: 'UI/UX Design Tutorial',
    skill: 'UI/UX Design',
    description: 'Learn user interface and user experience design from scratch with Figma.',
    platform: 'YouTube',
    priceType: 'free',
    priceAmount: 0,
    url: 'https://www.youtube.com/watch?v=c9Wg6Cb_YlU',
    difficultyLevel: 'beginner',
    durationHours: 5,
    rating: 4.8,
    thumbnailUrl: 'https://images.pexels.com/photos/196644/pexels-photo-196644.jpeg',
    tags: ['design', 'figma', 'ux']
  },
  {
    id: '15',
    title: 'Complete Ethical Hacking Course',
    skill: 'Cybersecurity',
    description: 'Learn ethical hacking from scratch - become a cybersecurity professional.',
    platform: 'Udemy',
    priceType: 'paid',
    priceAmount: 99.99,
    url: 'https://www.udemy.com/course/learn-ethical-hacking-from-scratch/',
    difficultyLevel: 'intermediate',
    durationHours: 42,
    rating: 4.6,
    thumbnailUrl: 'https://images.pexels.com/photos/60504/security-protection-anti-virus-software-60504.jpeg',
    tags: ['security', 'hacking', 'networking']
  }
];

export const mockTests: Test[] = [
  {
    id: 't1',
    skill: 'Python',
    title: 'Python Fundamentals Assessment',
    description: 'Test your knowledge of Python basics including data types, control structures, and functions.',
    difficultyLevel: 'beginner',
    totalPoints: 100,
    timeLimitMinutes: 30,
    questions: [
      {
        id: 'q1',
        question: 'What is the correct way to declare a variable in Python?',
        options: ['var x = 5', 'int x = 5', 'x = 5', 'let x = 5'],
        correctAnswer: 2,
        points: 10
      },
      {
        id: 'q2',
        question: 'Which data type is mutable in Python?',
        options: ['tuple', 'string', 'list', 'integer'],
        correctAnswer: 2,
        points: 10
      },
      {
        id: 'q3',
        question: 'What does the len() function do?',
        options: ['Returns the length of an object', 'Converts to string', 'Creates a list', 'Deletes an element'],
        correctAnswer: 0,
        points: 10
      },
      {
        id: 'q4',
        question: 'How do you start a comment in Python?',
        options: ['//', '/*', '#', '<!--'],
        correctAnswer: 2,
        points: 10
      },
      {
        id: 'q5',
        question: 'What is the output of print(type([]))?',
        options: ['<class \'list\'>', '<class \'array\'>', '<class \'tuple\'>', '<class \'dict\'>'],
        correctAnswer: 0,
        points: 10
      },
      {
        id: 'q6',
        question: 'Which keyword is used to define a function in Python?',
        options: ['function', 'def', 'func', 'define'],
        correctAnswer: 1,
        points: 10
      },
      {
        id: 'q7',
        question: 'What is the correct syntax for a for loop?',
        options: ['for (i in range(5))', 'for i in range(5):', 'foreach i in range(5)', 'for i = 0 to 5'],
        correctAnswer: 1,
        points: 10
      },
      {
        id: 'q8',
        question: 'How do you create a dictionary in Python?',
        options: ['[]', '()', '{}', '<>'],
        correctAnswer: 2,
        points: 10
      },
      {
        id: 'q9',
        question: 'What does the append() method do?',
        options: ['Removes an item', 'Adds an item to the end', 'Sorts the list', 'Clears the list'],
        correctAnswer: 1,
        points: 10
      },
      {
        id: 'q10',
        question: 'Which operator is used for exponentiation?',
        options: ['^', '**', '^^', 'exp()'],
        correctAnswer: 1,
        points: 10
      }
    ]
  },
  {
    id: 't2',
    skill: 'JavaScript',
    title: 'JavaScript Essentials Quiz',
    description: 'Evaluate your understanding of JavaScript fundamentals and modern ES6+ features.',
    difficultyLevel: 'beginner',
    totalPoints: 100,
    timeLimitMinutes: 25,
    questions: [
      {
        id: 'q1',
        question: 'What keyword is used to declare a block-scoped variable?',
        options: ['var', 'let', 'const', 'both let and const'],
        correctAnswer: 3,
        points: 10
      },
      {
        id: 'q2',
        question: 'What is the output of typeof null?',
        options: ['null', 'undefined', 'object', 'number'],
        correctAnswer: 2,
        points: 10
      },
      {
        id: 'q3',
        question: 'Which method adds an element to the end of an array?',
        options: ['push()', 'pop()', 'shift()', 'unshift()'],
        correctAnswer: 0,
        points: 10
      },
      {
        id: 'q4',
        question: 'What does === operator check?',
        options: ['Value only', 'Type only', 'Both value and type', 'Reference'],
        correctAnswer: 2,
        points: 10
      },
      {
        id: 'q5',
        question: 'How do you write an arrow function?',
        options: ['function() => {}', '() => {}', 'arrow() {}', '-> {}'],
        correctAnswer: 1,
        points: 10
      },
      {
        id: 'q6',
        question: 'What method is used to parse a JSON string?',
        options: ['JSON.parse()', 'JSON.stringify()', 'JSON.decode()', 'JSON.read()'],
        correctAnswer: 0,
        points: 10
      },
      {
        id: 'q7',
        question: 'What does the map() method do?',
        options: ['Filters array', 'Creates new array with results', 'Sorts array', 'Finds element'],
        correctAnswer: 1,
        points: 10
      },
      {
        id: 'q8',
        question: 'How do you handle asynchronous operations?',
        options: ['Callbacks', 'Promises', 'Async/Await', 'All of the above'],
        correctAnswer: 3,
        points: 10
      },
      {
        id: 'q9',
        question: 'What is closure in JavaScript?',
        options: ['Function ending', 'Function inside function with access to outer scope', 'Closing brackets', 'Error handling'],
        correctAnswer: 1,
        points: 10
      },
      {
        id: 'q10',
        question: 'What does the spread operator (...) do?',
        options: ['Multiplies numbers', 'Expands iterables', 'Divides arrays', 'Concatenates strings'],
        correctAnswer: 1,
        points: 10
      }
    ]
  },
  {
    id: 't3',
    skill: 'React',
    title: 'React Fundamentals Test',
    description: 'Test your React knowledge including components, hooks, and state management.',
    difficultyLevel: 'intermediate',
    totalPoints: 100,
    timeLimitMinutes: 30,
    questions: [
      {
        id: 'q1',
        question: 'What is JSX?',
        options: ['JavaScript XML', 'Java Syntax Extension', 'JSON XML', 'JavaScript Extension'],
        correctAnswer: 0,
        points: 10
      },
      {
        id: 'q2',
        question: 'Which hook is used for side effects?',
        options: ['useState', 'useEffect', 'useContext', 'useReducer'],
        correctAnswer: 1,
        points: 10
      },
      {
        id: 'q3',
        question: 'How do you pass data from parent to child?',
        options: ['Props', 'State', 'Context', 'Redux'],
        correctAnswer: 0,
        points: 10
      },
      {
        id: 'q4',
        question: 'What is the virtual DOM?',
        options: ['Browser DOM', 'Lightweight copy of DOM', 'Database', 'API'],
        correctAnswer: 1,
        points: 10
      },
      {
        id: 'q5',
        question: 'Which hook manages component state?',
        options: ['useState', 'useEffect', 'useRef', 'useMemo'],
        correctAnswer: 0,
        points: 10
      },
      {
        id: 'q6',
        question: 'What are keys used for in React lists?',
        options: ['Styling', 'Identifying elements uniquely', 'Data storage', 'Routing'],
        correctAnswer: 1,
        points: 10
      },
      {
        id: 'q7',
        question: 'What is prop drilling?',
        options: ['Optimizing props', 'Passing props through multiple levels', 'Deleting props', 'Validating props'],
        correctAnswer: 1,
        points: 10
      },
      {
        id: 'q8',
        question: 'What does useContext hook do?',
        options: ['Creates context', 'Consumes context', 'Updates context', 'Deletes context'],
        correctAnswer: 1,
        points: 10
      },
      {
        id: 'q9',
        question: 'When does useEffect run by default?',
        options: ['Once on mount', 'After every render', 'On unmount', 'Never'],
        correctAnswer: 1,
        points: 10
      },
      {
        id: 'q10',
        question: 'What is the purpose of useMemo?',
        options: ['Memoize values', 'Memoize functions', 'Create refs', 'Manage state'],
        correctAnswer: 0,
        points: 10
      }
    ]
  }
];

export const mockBadges: Badge[] = [
  {
    id: 'b1',
    name: 'First Steps',
    description: 'Completed your first course',
    icon: 'Award',
    pointsValue: 50
  },
  {
    id: 'b2',
    name: 'Quick Learner',
    description: 'Completed 5 courses',
    icon: 'Zap',
    pointsValue: 100
  },
  {
    id: 'b3',
    name: 'Knowledge Seeker',
    description: 'Completed 10 courses',
    icon: 'BookOpen',
    pointsValue: 200
  },
  {
    id: 'b4',
    name: 'Test Master',
    description: 'Scored 90% or higher on 5 tests',
    icon: 'Trophy',
    pointsValue: 150
  },
  {
    id: 'b5',
    name: 'Week Warrior',
    description: 'Maintained a 7-day learning streak',
    icon: 'Flame',
    pointsValue: 100
  },
  {
    id: 'b6',
    name: 'Dedicated Learner',
    description: 'Spent 50+ hours learning',
    icon: 'Clock',
    pointsValue: 250
  },
  {
    id: 'b7',
    name: 'Jack of All Trades',
    description: 'Learned 5 different skills',
    icon: 'Target',
    pointsValue: 300
  },
  {
    id: 'b8',
    name: 'Perfect Score',
    description: 'Scored 100% on any test',
    icon: 'Star',
    pointsValue: 200
  }
];
