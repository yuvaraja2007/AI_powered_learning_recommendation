export interface User {
  id: string;
  username: string;
  email: string;
  skillInterests: string[];
  skillLevels: Record<string, string>;
  preferredPlatforms: string[];
  learningBudget: 'free' | 'paid' | 'both';
  weeklyGoalHours: number;
  totalPoints: number;
  currentStreak: number;
  createdAt: Date;
}

export interface Course {
  id: string;
  title: string;
  skill: string;
  description: string;
  platform: string;
  priceType: 'free' | 'paid';
  priceAmount: number;
  url: string;
  difficultyLevel: 'beginner' | 'intermediate' | 'advanced';
  durationHours: number;
  rating: number;
  thumbnailUrl: string;
  tags: string[];
}

export interface UserCourseProgress {
  id: string;
  userId: string;
  courseId: string;
  status: 'enrolled' | 'in_progress' | 'completed';
  progressPercentage: number;
  timeSpentHours: number;
  startedAt: Date;
  completedAt?: Date;
  ratingGiven?: number;
}

export interface Question {
  id: string;
  question: string;
  options: string[];
  correctAnswer: number;
  points: number;
}

export interface Test {
  id: string;
  skill: string;
  title: string;
  description: string;
  difficultyLevel: 'beginner' | 'intermediate' | 'advanced';
  questions: Question[];
  totalPoints: number;
  timeLimitMinutes: number;
}

export interface TestAttempt {
  id: string;
  userId: string;
  testId: string;
  score: number;
  totalPoints: number;
  percentage: number;
  answers: Record<string, number>;
  timeTakenMinutes: number;
  completedAt: Date;
}

export interface Badge {
  id: string;
  name: string;
  description: string;
  icon: string;
  pointsValue: number;
}

export interface UserBadge {
  id: string;
  userId: string;
  badge: Badge;
  earnedAt: Date;
}

export interface ChatMessage {
  id: string;
  userId: string;
  message: string;
  response: string;
  createdAt: Date;
}

export interface LearningPlan {
  id: string;
  userId: string;
  weekStartDate: Date;
  courses: Course[];
  goals: {
    hoursToSpend: number;
    coursesToComplete: number;
    skillsToImprove: string[];
  };
}
