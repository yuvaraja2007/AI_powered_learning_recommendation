import React, { useMemo } from 'react';
import { motion } from 'framer-motion';
import { Trophy, Medal, Award, TrendingUp, User } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export default function Leaderboard() {
  const { user } = useAuth();

  const mockLeaderboard = useMemo(() => {
    const users = [
      { id: '1', username: 'CodeMaster', totalPoints: 2850, completedCourses: 15, badges: 8 },
      { id: '2', username: 'LearnGeek', totalPoints: 2650, completedCourses: 13, badges: 7 },
      { id: '3', username: 'TechWizard', totalPoints: 2420, completedCourses: 12, badges: 6 },
      { id: '4', username: 'DataNinja', totalPoints: 2180, completedCourses: 11, badges: 6 },
      { id: '5', username: 'PyThanos', totalPoints: 1950, completedCourses: 10, badges: 5 },
      { id: user?.id || '6', username: user?.username || 'You', totalPoints: user?.totalPoints || 0, completedCourses: 0, badges: 0 },
      { id: '7', username: 'WebDevPro', totalPoints: 1780, completedCourses: 9, badges: 5 },
      { id: '8', username: 'AIEnthusiast', totalPoints: 1650, completedCourses: 8, badges: 4 },
      { id: '9', username: 'CloudGuru', totalPoints: 1520, completedCourses: 8, badges: 4 },
      { id: '10', username: 'FullStackJoe', totalPoints: 1420, completedCourses: 7, badges: 3 }
    ];

    return users.sort((a, b) => b.totalPoints - a.totalPoints);
  }, [user]);

  const userRank = mockLeaderboard.findIndex(u => u.id === user?.id) + 1;

  return (
    <div className="max-w-5xl mx-auto space-y-8">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2 flex items-center justify-center gap-3">
          <Trophy className="w-8 h-8 text-yellow-500" />
          Leaderboard
        </h1>
        <p className="text-gray-600">Compete with fellow learners and climb the ranks!</p>
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-gradient-to-r from-blue-600 to-cyan-600 rounded-xl shadow-lg p-6 text-white"
      >
        <div className="flex items-center justify-between">
          <div>
            <p className="text-blue-100 mb-1">Your Rank</p>
            <p className="text-4xl font-bold">#{userRank}</p>
          </div>
          <div className="text-right">
            <p className="text-blue-100 mb-1">Total Points</p>
            <p className="text-4xl font-bold">{user?.totalPoints || 0}</p>
          </div>
          <div className="w-20 h-20 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center">
            {userRank <= 3 ? (
              <Trophy className="w-10 h-10" />
            ) : (
              <Medal className="w-10 h-10" />
            )}
          </div>
        </div>
      </motion.div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        {mockLeaderboard.slice(0, 3).map((leader, index) => {
          const medals = [
            { bg: 'from-yellow-400 to-yellow-600', icon: 'text-yellow-50' },
            { bg: 'from-gray-300 to-gray-500', icon: 'text-gray-50' },
            { bg: 'from-orange-400 to-orange-600', icon: 'text-orange-50' }
          ];
          const medal = medals[index];

          return (
            <motion.div
              key={leader.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className={`bg-gradient-to-br ${medal.bg} rounded-xl p-6 text-white text-center relative overflow-hidden`}
            >
              <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -mr-16 -mt-16" />
              <div className="relative">
                <div className="w-20 h-20 bg-white/20 backdrop-blur-sm rounded-full mx-auto mb-4 flex items-center justify-center">
                  <Trophy className={`w-10 h-10 ${medal.icon}`} />
                </div>
                <p className="text-3xl font-bold mb-1">#{index + 1}</p>
                <p className="text-lg font-semibold mb-2">{leader.username}</p>
                <p className="text-2xl font-bold">{leader.totalPoints} pts</p>
                <div className="flex items-center justify-center gap-4 mt-4 text-sm">
                  <span>{leader.completedCourses} courses</span>
                  <span>{leader.badges} badges</span>
                </div>
              </div>
            </motion.div>
          );
        })}
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="bg-white rounded-xl shadow-sm overflow-hidden"
      >
        <div className="p-6 border-b border-gray-200">
          <h2 className="text-xl font-bold text-gray-900 flex items-center gap-2">
            <TrendingUp className="w-6 h-6 text-blue-600" />
            All Learners
          </h2>
        </div>

        <div className="divide-y divide-gray-200">
          {mockLeaderboard.map((leader, index) => {
            const isCurrentUser = leader.id === user?.id;
            return (
              <motion.div
                key={leader.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.4 + index * 0.05 }}
                className={`p-4 hover:bg-gray-50 transition-colors ${
                  isCurrentUser ? 'bg-blue-50 border-l-4 border-blue-600' : ''
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-lg ${
                      index === 0 ? 'bg-yellow-100 text-yellow-700' :
                      index === 1 ? 'bg-gray-100 text-gray-700' :
                      index === 2 ? 'bg-orange-100 text-orange-700' :
                      'bg-gray-100 text-gray-600'
                    }`}>
                      {index + 1}
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-cyan-600 rounded-full flex items-center justify-center">
                        <User className="w-5 h-5 text-white" />
                      </div>
                      <div>
                        <p className="font-semibold text-gray-900">
                          {leader.username}
                          {isCurrentUser && (
                            <span className="ml-2 text-xs bg-blue-100 text-blue-700 px-2 py-1 rounded-full">
                              You
                            </span>
                          )}
                        </p>
                        <p className="text-sm text-gray-600">
                          {leader.completedCourses} courses • {leader.badges} badges
                        </p>
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-2xl font-bold text-gray-900">{leader.totalPoints}</p>
                    <p className="text-sm text-gray-600">points</p>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.6 }}
        className="bg-gradient-to-br from-purple-50 to-pink-50 rounded-xl p-6 border-2 border-purple-200"
      >
        <div className="flex items-center gap-3 mb-4">
          <Award className="w-8 h-8 text-purple-600" />
          <h3 className="text-xl font-bold text-gray-900">How to Earn Points</h3>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="bg-white rounded-lg p-4">
            <p className="font-semibold text-gray-900 mb-1">Complete Courses</p>
            <p className="text-sm text-gray-600">Earn points for every course you finish</p>
          </div>
          <div className="bg-white rounded-lg p-4">
            <p className="font-semibold text-gray-900 mb-1">Ace Tests</p>
            <p className="text-sm text-gray-600">Score high on skill assessments</p>
          </div>
          <div className="bg-white rounded-lg p-4">
            <p className="font-semibold text-gray-900 mb-1">Earn Badges</p>
            <p className="text-sm text-gray-600">Unlock achievements and badges</p>
          </div>
          <div className="bg-white rounded-lg p-4">
            <p className="font-semibold text-gray-900 mb-1">Stay Consistent</p>
            <p className="text-sm text-gray-600">Maintain learning streaks</p>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
