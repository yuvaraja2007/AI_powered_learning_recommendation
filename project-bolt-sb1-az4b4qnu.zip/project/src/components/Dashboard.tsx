import React, { useMemo } from 'react';
import { motion } from 'framer-motion';
import {
  BarChart, Bar, LineChart, Line, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer
} from 'recharts';
import {
  TrendingUp, BookOpen, Clock, Award, Target, Calendar,
  ExternalLink, Star, Zap
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { mockCourses } from '../data/mockData';
import { getRecommendedCourses, generateWeeklyPlan, analyzeSkillGaps } from '../utils/recommendations';

export default function Dashboard() {
  const { user, userProgress, testAttempts } = useAuth();

  const recommendedCourses = useMemo(
    () => getRecommendedCourses(user!, mockCourses, userProgress),
    [user, userProgress]
  );

  const weeklyPlan = useMemo(
    () => generateWeeklyPlan(user!, recommendedCourses),
    [user, recommendedCourses]
  );

  const skillGaps = useMemo(
    () => analyzeSkillGaps(user!, mockCourses, userProgress),
    [user, userProgress]
  );

  const completedCourses = userProgress.filter(p => p.status === 'completed').length;
  const inProgressCourses = userProgress.filter(p => p.status === 'in_progress').length;
  const totalHoursSpent = userProgress.reduce((sum, p) => sum + p.timeSpentHours, 0);

  const skillLevelData = Object.entries(user?.skillLevels || {}).map(([skill, level]) => ({
    skill,
    level: level === 'beginner' ? 1 : level === 'intermediate' ? 2 : 3
  }));

  const testScoreData = testAttempts.slice(-5).map((attempt, index) => ({
    test: `Test ${index + 1}`,
    score: attempt.percentage
  }));

  const progressData = [
    { name: 'Completed', value: completedCourses, color: '#10b981' },
    { name: 'In Progress', value: inProgressCourses, color: '#3b82f6' },
    { name: 'Recommended', value: Math.max(0, 5 - completedCourses - inProgressCourses), color: '#d1d5db' }
  ];

  return (
    <div className="max-w-7xl mx-auto space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            Welcome back, {user?.username}!
          </h1>
          <p className="text-gray-600">Here's your personalized learning dashboard</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard
          icon={BookOpen}
          label="Completed Courses"
          value={completedCourses}
          color="blue"
        />
        <StatCard
          icon={Clock}
          label="Hours Learned"
          value={Math.round(totalHoursSpent)}
          color="green"
        />
        <StatCard
          icon={Award}
          label="Total Points"
          value={user?.totalPoints || 0}
          color="yellow"
        />
        <StatCard
          icon={Zap}
          label="Current Streak"
          value={user?.currentStreak || 0}
          color="red"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-xl shadow-sm p-6"
        >
          <h2 className="text-xl font-bold text-gray-900 mb-4 flex items-center gap-2">
            <TrendingUp className="w-6 h-6 text-blue-600" />
            Test Performance
          </h2>
          {testScoreData.length > 0 ? (
            <ResponsiveContainer width="100%" height={250}>
              <LineChart data={testScoreData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="test" />
                <YAxis domain={[0, 100]} />
                <Tooltip />
                <Line
                  type="monotone"
                  dataKey="score"
                  stroke="#3b82f6"
                  strokeWidth={2}
                  dot={{ fill: '#3b82f6', r: 4 }}
                />
              </LineChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-64 flex items-center justify-center text-gray-500">
              Take tests to see your performance
            </div>
          )}
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-white rounded-xl shadow-sm p-6"
        >
          <h2 className="text-xl font-bold text-gray-900 mb-4 flex items-center gap-2">
            <Target className="w-6 h-6 text-blue-600" />
            Course Progress
          </h2>
          {progressData.some(d => d.value > 0) ? (
            <ResponsiveContainer width="100%" height={250}>
              <PieChart>
                <Pie
                  data={progressData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, value }) => `${name}: ${value}`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {progressData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-64 flex items-center justify-center text-gray-500">
              Start courses to track progress
            </div>
          )}
        </motion.div>
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="bg-gradient-to-br from-blue-600 to-cyan-600 rounded-xl shadow-lg p-6 text-white"
      >
        <div className="flex items-center gap-3 mb-4">
          <Calendar className="w-7 h-7" />
          <h2 className="text-2xl font-bold">Your Weekly Learning Plan</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          {weeklyPlan.goals.map((goal, index) => (
            <div key={index} className="bg-white/10 backdrop-blur-sm rounded-lg p-4">
              <p className="text-sm font-medium">{goal}</p>
            </div>
          ))}
        </div>

        <div className="space-y-3">
          <h3 className="text-lg font-semibold mb-3">Recommended Courses This Week:</h3>
          {weeklyPlan.courses.slice(0, 3).map((course) => (
            <div
              key={course.id}
              className="bg-white/10 backdrop-blur-sm rounded-lg p-4 flex items-center justify-between"
            >
              <div className="flex-1">
                <p className="font-semibold mb-1">{course.title}</p>
                <div className="flex items-center gap-3 text-sm">
                  <span className="flex items-center gap-1">
                    <Clock className="w-4 h-4" />
                    {course.durationHours}h
                  </span>
                  <span className="flex items-center gap-1">
                    <Star className="w-4 h-4" />
                    {course.rating}
                  </span>
                  <span className="bg-white/20 px-2 py-0.5 rounded">
                    {course.platform}
                  </span>
                </div>
              </div>
              <a
                href={course.url}
                target="_blank"
                rel="noopener noreferrer"
                className="ml-4 p-2 bg-white text-blue-600 rounded-lg hover:bg-white/90 transition-colors"
              >
                <ExternalLink className="w-5 h-5" />
              </a>
            </div>
          ))}
        </div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="bg-white rounded-xl shadow-sm p-6"
      >
        <h2 className="text-xl font-bold text-gray-900 mb-4 flex items-center gap-2">
          <Target className="w-6 h-6 text-blue-600" />
          Skill Gap Analysis
        </h2>
        {skillGaps.length > 0 ? (
          <div className="space-y-6">
            {skillGaps.map((gap) => (
              <div key={gap.skill} className="border-l-4 border-blue-600 pl-4">
                <h3 className="font-semibold text-lg text-gray-900 mb-2">
                  {gap.skill} → {gap.level}
                </h3>
                <p className="text-sm text-gray-600 mb-3">
                  Ready to advance to {gap.level} level? Try these courses:
                </p>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  {gap.suggestedCourses.map((course) => (
                    <a
                      key={course.id}
                      href={course.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="p-3 border border-gray-200 rounded-lg hover:border-blue-600 hover:shadow-md transition-all group"
                    >
                      <p className="font-medium text-sm text-gray-900 group-hover:text-blue-600 mb-1 line-clamp-2">
                        {course.title}
                      </p>
                      <div className="flex items-center justify-between text-xs text-gray-500">
                        <span>{course.platform}</span>
                        <span className="flex items-center gap-1">
                          <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                          {course.rating}
                        </span>
                      </div>
                    </a>
                  ))}
                </div>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-gray-500">
            Complete more courses to get personalized skill gap analysis
          </p>
        )}
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="bg-white rounded-xl shadow-sm p-6"
      >
        <h2 className="text-xl font-bold text-gray-900 mb-4">
          Recommended Courses For You
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {recommendedCourses.slice(0, 6).map((course, index) => (
            <motion.div
              key={course.id}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.4 + index * 0.05 }}
              className="border border-gray-200 rounded-lg p-4 hover:border-blue-600 hover:shadow-lg transition-all"
            >
              <div className="flex items-start justify-between mb-2">
                <span className="text-xs font-semibold text-blue-600 bg-blue-50 px-2 py-1 rounded">
                  {course.skill}
                </span>
                {course.priceType === 'free' ? (
                  <span className="text-xs font-bold text-green-600 bg-green-50 px-2 py-1 rounded">
                    FREE
                  </span>
                ) : (
                  <span className="text-xs font-bold text-blue-600 bg-blue-50 px-2 py-1 rounded">
                    ${course.priceAmount}
                  </span>
                )}
              </div>
              <h3 className="font-semibold text-gray-900 mb-2 line-clamp-2">
                {course.title}
              </h3>
              <div className="flex items-center justify-between text-sm text-gray-500 mb-3">
                <span>{course.platform}</span>
                <span className="flex items-center gap-1">
                  <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                  {course.rating}
                </span>
              </div>
              <a
                href={course.url}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center gap-2 w-full bg-blue-600 text-white py-2 rounded-lg text-sm font-semibold hover:bg-blue-700 transition-colors"
              >
                View Course
                <ExternalLink className="w-4 h-4" />
              </a>
            </motion.div>
          ))}
        </div>
      </motion.div>
    </div>
  );
}

function StatCard({
  icon: Icon,
  label,
  value,
  color
}: {
  icon: any;
  label: string;
  value: number;
  color: string;
}) {
  const colors = {
    blue: 'from-blue-500 to-blue-600',
    green: 'from-green-500 to-green-600',
    yellow: 'from-yellow-500 to-yellow-600',
    red: 'from-red-500 to-red-600'
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ y: -5 }}
      className="bg-white rounded-xl shadow-sm p-6 hover:shadow-lg transition-all"
    >
      <div className="flex items-center justify-between mb-3">
        <div className={`w-12 h-12 bg-gradient-to-br ${colors[color as keyof typeof colors]} rounded-lg flex items-center justify-center`}>
          <Icon className="w-6 h-6 text-white" />
        </div>
      </div>
      <p className="text-3xl font-bold text-gray-900 mb-1">{value}</p>
      <p className="text-sm text-gray-600">{label}</p>
    </motion.div>
  );
}
