import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { User, Award, BookOpen, Trophy, Edit2, Save, X } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { SKILLS, PLATFORMS } from '../data/mockData';
import * as LucideIcons from 'lucide-react';

export default function Profile() {
  const { user, updateProfile, userProgress, userBadges, testAttempts } = useAuth();
  const [editing, setEditing] = useState(false);
  const [formData, setFormData] = useState({
    username: user?.username || '',
    weeklyGoalHours: user?.weeklyGoalHours || 5,
    preferredPlatforms: user?.preferredPlatforms || [],
    learningBudget: user?.learningBudget || 'both'
  });

  const completedCourses = userProgress.filter(p => p.status === 'completed').length;
  const totalHours = userProgress.reduce((sum, p) => sum + p.timeSpentHours, 0);
  const avgTestScore = testAttempts.length > 0
    ? testAttempts.reduce((sum, a) => sum + a.percentage, 0) / testAttempts.length
    : 0;

  const handleSave = () => {
    updateProfile(formData);
    setEditing(false);
  };

  const togglePlatform = (platform: string) => {
    setFormData(prev => ({
      ...prev,
      preferredPlatforms: prev.preferredPlatforms.includes(platform)
        ? prev.preferredPlatforms.filter(p => p !== platform)
        : [...prev.preferredPlatforms, platform]
    }));
  };

  return (
    <div className="max-w-6xl mx-auto space-y-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-gradient-to-r from-blue-600 to-cyan-600 rounded-xl shadow-lg p-8 text-white"
      >
        <div className="flex items-start justify-between mb-6">
          <div className="flex items-center gap-4">
            <div className="w-20 h-20 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center">
              <User className="w-10 h-10" />
            </div>
            <div>
              <h1 className="text-3xl font-bold">{user?.username}</h1>
              <p className="text-blue-100">{user?.email}</p>
            </div>
          </div>
          {!editing ? (
            <button
              onClick={() => setEditing(true)}
              className="px-4 py-2 bg-white/20 backdrop-blur-sm hover:bg-white/30 rounded-lg flex items-center gap-2 transition-colors"
            >
              <Edit2 className="w-4 h-4" />
              Edit Profile
            </button>
          ) : (
            <div className="flex gap-2">
              <button
                onClick={handleSave}
                className="px-4 py-2 bg-white text-blue-600 hover:bg-blue-50 rounded-lg flex items-center gap-2 transition-colors"
              >
                <Save className="w-4 h-4" />
                Save
              </button>
              <button
                onClick={() => {
                  setEditing(false);
                  setFormData({
                    username: user?.username || '',
                    weeklyGoalHours: user?.weeklyGoalHours || 5,
                    preferredPlatforms: user?.preferredPlatforms || [],
                    learningBudget: user?.learningBudget || 'both'
                  });
                }}
                className="px-4 py-2 bg-white/20 backdrop-blur-sm hover:bg-white/30 rounded-lg flex items-center gap-2 transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4">
            <Trophy className="w-8 h-8 mb-2" />
            <p className="text-2xl font-bold">{user?.totalPoints}</p>
            <p className="text-sm text-blue-100">Total Points</p>
          </div>
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4">
            <BookOpen className="w-8 h-8 mb-2" />
            <p className="text-2xl font-bold">{completedCourses}</p>
            <p className="text-sm text-blue-100">Courses Completed</p>
          </div>
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4">
            <Award className="w-8 h-8 mb-2" />
            <p className="text-2xl font-bold">{userBadges.length}</p>
            <p className="text-sm text-blue-100">Badges Earned</p>
          </div>
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4">
            <Trophy className="w-8 h-8 mb-2" />
            <p className="text-2xl font-bold">{avgTestScore.toFixed(0)}%</p>
            <p className="text-sm text-blue-100">Avg Test Score</p>
          </div>
        </div>
      </motion.div>

      {editing ? (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-xl shadow-sm p-6"
        >
          <h2 className="text-xl font-bold text-gray-900 mb-6">Edit Profile</h2>
          <div className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Username
              </label>
              <input
                type="text"
                value={formData.username}
                onChange={(e) => setFormData({ ...formData, username: e.target.value })}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Weekly Goal (hours)
              </label>
              <input
                type="number"
                value={formData.weeklyGoalHours}
                onChange={(e) => setFormData({ ...formData, weeklyGoalHours: parseInt(e.target.value) })}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                min="1"
                max="50"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Learning Budget
              </label>
              <select
                value={formData.learningBudget}
                onChange={(e) => setFormData({ ...formData, learningBudget: e.target.value as any })}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="both">Both Free & Paid</option>
                <option value="free">Free Only</option>
                <option value="paid">Paid Only</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-3">
                Preferred Platforms
              </label>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                {PLATFORMS.map(platform => (
                  <button
                    key={platform}
                    type="button"
                    onClick={() => togglePlatform(platform)}
                    className={`px-3 py-2 rounded-lg text-sm font-medium transition-all ${
                      formData.preferredPlatforms.includes(platform)
                        ? 'bg-blue-600 text-white'
                        : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                    }`}
                  >
                    {platform}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </motion.div>
      ) : (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-xl shadow-sm p-6"
        >
          <h2 className="text-xl font-bold text-gray-900 mb-6">Skill Levels</h2>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {user?.skillInterests.map(skill => {
              const level = user.skillLevels[skill] || 'beginner';
              return (
                <div key={skill} className="border border-gray-200 rounded-lg p-4">
                  <p className="font-semibold text-gray-900 mb-2">{skill}</p>
                  <span className={`text-xs px-2 py-1 rounded font-semibold ${
                    level === 'beginner' ? 'bg-green-100 text-green-700' :
                    level === 'intermediate' ? 'bg-yellow-100 text-yellow-700' :
                    'bg-red-100 text-red-700'
                  }`}>
                    {level}
                  </span>
                </div>
              );
            })}
          </div>
        </motion.div>
      )}

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="bg-white rounded-xl shadow-sm p-6"
      >
        <h2 className="text-xl font-bold text-gray-900 mb-6 flex items-center gap-2">
          <Award className="w-6 h-6 text-blue-600" />
          Badges Collection
        </h2>
        {userBadges.length > 0 ? (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {userBadges.map((userBadge) => {
              const IconComponent = (LucideIcons as any)[userBadge.badge.icon] || Award;
              return (
                <motion.div
                  key={userBadge.id}
                  whileHover={{ scale: 1.05 }}
                  className="bg-gradient-to-br from-yellow-50 to-orange-50 rounded-xl p-6 text-center border-2 border-yellow-200"
                >
                  <div className="w-16 h-16 mx-auto mb-3 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-full flex items-center justify-center">
                    <IconComponent className="w-8 h-8 text-white" />
                  </div>
                  <h3 className="font-bold text-gray-900 mb-1">{userBadge.badge.name}</h3>
                  <p className="text-xs text-gray-600 mb-2">{userBadge.badge.description}</p>
                  <span className="text-xs font-semibold text-yellow-700 bg-yellow-100 px-2 py-1 rounded">
                    +{userBadge.badge.pointsValue} pts
                  </span>
                </motion.div>
              );
            })}
          </div>
        ) : (
          <div className="text-center py-12">
            <Award className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <p className="text-gray-500">Complete courses and tests to earn badges!</p>
          </div>
        )}
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="bg-white rounded-xl shadow-sm p-6"
      >
        <h2 className="text-xl font-bold text-gray-900 mb-6">Learning Activity</h2>
        <div className="space-y-4">
          {userProgress.length > 0 ? (
            userProgress.slice(-5).reverse().map((progress) => (
              <div key={progress.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <div className="flex items-center gap-3">
                  <BookOpen className="w-5 h-5 text-blue-600" />
                  <div>
                    <p className="font-semibold text-gray-900">Course Progress</p>
                    <p className="text-sm text-gray-600">{progress.status}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-semibold text-gray-900">{progress.progressPercentage}%</p>
                  <p className="text-sm text-gray-600">{progress.timeSpentHours.toFixed(1)}h</p>
                </div>
              </div>
            ))
          ) : (
            <div className="text-center py-12">
              <BookOpen className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-500">Start learning to track your activity!</p>
            </div>
          )}
        </div>
      </motion.div>
    </div>
  );
}
