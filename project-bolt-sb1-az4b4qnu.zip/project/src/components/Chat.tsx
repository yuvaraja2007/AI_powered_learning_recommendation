import React, { useState, useRef, useEffect } from 'react';
import { motion } from 'framer-motion';
import { MessageSquare, Send, Bot, User as UserIcon, Sparkles } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { mockCourses } from '../data/mockData';

export default function Chat() {
  const [message, setMessage] = useState('');
  const [messages, setMessages] = useState<Array<{ role: 'user' | 'assistant'; content: string }>>([
    {
      role: 'assistant',
      content: 'Hello! I\'m your AI Learning Mentor. I can help you find courses, answer questions about learning paths, and provide study guidance. What would you like to know?'
    }
  ]);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { user, addChatMessage } = useAuth();

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const generateResponse = (userMessage: string): string => {
    const lowerMessage = userMessage.toLowerCase();

    if (lowerMessage.includes('python') && (lowerMessage.includes('best') || lowerMessage.includes('recommend'))) {
      const pythonCourses = mockCourses.filter(c => c.skill === 'Python').slice(0, 3);
      return `Great choice! Here are the top Python courses I recommend:\n\n${pythonCourses.map((c, i) =>
        `${i + 1}. ${c.title} (${c.platform}) - ${c.priceType === 'free' ? 'Free' : '$' + c.priceAmount}`
      ).join('\n')}\n\nPython is perfect for beginners and has applications in web development, data science, and automation!`;
    }

    if (lowerMessage.includes('free') && lowerMessage.includes('course')) {
      const freeCourses = mockCourses.filter(c => c.priceType === 'free').slice(0, 4);
      return `Here are some excellent free courses:\n\n${freeCourses.map((c, i) =>
        `${i + 1}. ${c.title} (${c.platform}) - ${c.skill}`
      ).join('\n')}\n\nAll of these are high-quality and perfect for getting started!`;
    }

    if (lowerMessage.includes('which platform') || lowerMessage.includes('youtube') || lowerMessage.includes('udemy') || lowerMessage.includes('coursera')) {
      return `Each platform has its strengths:\n\n• YouTube & freeCodeCamp: Best for free, community-driven content\n• Udemy: Great for practical, project-based courses at affordable prices\n• Coursera: Excellent for university-level courses and certifications\n• edX: Similar to Coursera with focus on academic content\n\nFor ${user?.skillInterests[0] || 'your interests'}, I'd recommend starting with free resources on YouTube to get a feel, then investing in a structured Udemy or Coursera course.`;
    }

    if (lowerMessage.includes('beginner') || lowerMessage.includes('start')) {
      return `For beginners, I recommend:\n\n1. Start with fundamentals - don't rush!\n2. Practice daily, even if just 30 minutes\n3. Build small projects to apply what you learn\n4. Join communities (Reddit, Discord) for support\n5. Don't compare your progress to others\n\nBased on your interests in ${user?.skillInterests.slice(0, 2).join(' and ') || 'technology'}, you're on the right track!`;
    }

    if (lowerMessage.includes('how long') || lowerMessage.includes('time')) {
      return `Learning timelines vary by person, but here's a general guide:\n\n• Basics: 2-3 months with consistent practice\n• Intermediate: 6-12 months\n• Advanced: 1-2+ years\n\nThe key is consistency! Studying 1 hour daily is better than 7 hours once a week. Set realistic goals and celebrate small wins!`;
    }

    if (lowerMessage.includes('job') || lowerMessage.includes('career')) {
      return `To prepare for a tech career:\n\n1. Build a strong portfolio with real projects\n2. Contribute to open source\n3. Network through LinkedIn and tech communities\n4. Practice coding interviews (LeetCode, HackerRank)\n5. Learn Git and deployment basics\n6. Stay updated with industry trends\n\nYour skills in ${user?.skillInterests.slice(0, 2).join(' and ') || 'programming'} are valuable! Focus on building projects that showcase these skills.`;
    }

    if (lowerMessage.includes('stuck') || lowerMessage.includes('difficult') || lowerMessage.includes('hard')) {
      return `Feeling stuck is normal! Here's how to push through:\n\n1. Break the problem into smaller parts\n2. Take a break and come back fresh\n3. Explain the concept to someone else (rubber duck debugging!)\n4. Search for alternative explanations (different teachers explain differently)\n5. Join study groups or forums\n\nRemember: Every expert was once a beginner. You've got this! 💪`;
    }

    return `That's a great question! Based on your interests in ${user?.skillInterests.join(', ') || 'learning'}, I suggest:\n\n1. Check the Dashboard for personalized course recommendations\n2. Take skill assessments to identify your current level\n3. Follow your weekly learning plan consistently\n4. Explore different platforms to find your preferred learning style\n\nIs there a specific skill or topic you'd like to focus on? I can recommend targeted courses!`;
  };

  const handleSend = () => {
    if (!message.trim()) return;

    const userMessage = { role: 'user' as const, content: message };
    setMessages(prev => [...prev, userMessage]);

    setTimeout(() => {
      const response = generateResponse(message);
      const assistantMessage = { role: 'assistant' as const, content: response };
      setMessages(prev => [...prev, assistantMessage]);

      if (user) {
        addChatMessage({
          id: `msg_${Date.now()}`,
          userId: user.id,
          message: message,
          response: response,
          createdAt: new Date()
        });
      }
    }, 500);

    setMessage('');
  };

  return (
    <div className="max-w-5xl mx-auto h-[calc(100vh-12rem)]">
      <div className="bg-white rounded-xl shadow-lg h-full flex flex-col overflow-hidden">
        <div className="bg-gradient-to-r from-blue-600 to-cyan-600 p-6 text-white">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-white/20 backdrop-blur-sm rounded-xl flex items-center justify-center">
              <Sparkles className="w-6 h-6" />
            </div>
            <div>
              <h1 className="text-2xl font-bold">AI Learning Mentor</h1>
              <p className="text-sm text-blue-100">Ask me anything about courses and learning!</p>
            </div>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          {messages.map((msg, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className={`flex gap-3 ${msg.role === 'user' ? 'flex-row-reverse' : ''}`}
            >
              <div className={`w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 ${
                msg.role === 'user'
                  ? 'bg-gradient-to-br from-blue-600 to-cyan-600'
                  : 'bg-gradient-to-br from-purple-500 to-pink-500'
              }`}>
                {msg.role === 'user' ? (
                  <UserIcon className="w-5 h-5 text-white" />
                ) : (
                  <Bot className="w-5 h-5 text-white" />
                )}
              </div>
              <div className={`flex-1 max-w-3xl ${msg.role === 'user' ? 'text-right' : ''}`}>
                <div className={`inline-block px-4 py-3 rounded-2xl ${
                  msg.role === 'user'
                    ? 'bg-gradient-to-r from-blue-600 to-cyan-600 text-white'
                    : 'bg-gray-100 text-gray-900'
                }`}>
                  <p className="whitespace-pre-line">{msg.content}</p>
                </div>
              </div>
            </motion.div>
          ))}
          <div ref={messagesEndRef} />
        </div>

        <div className="border-t border-gray-200 p-4">
          <div className="flex gap-3">
            <input
              type="text"
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSend()}
              placeholder="Ask about courses, learning paths, or study tips..."
              className="flex-1 px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
            <button
              onClick={handleSend}
              disabled={!message.trim()}
              className="px-6 py-3 bg-gradient-to-r from-blue-600 to-cyan-600 text-white rounded-lg font-semibold hover:from-blue-700 hover:to-cyan-700 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
            >
              <Send className="w-5 h-5" />
              Send
            </button>
          </div>
          <p className="text-xs text-gray-500 mt-2">
            💡 Try asking: "Which platform is best for Python?" or "Recommend free courses"
          </p>
        </div>
      </div>
    </div>
  );
}
