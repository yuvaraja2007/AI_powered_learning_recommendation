import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, UserCourseProgress, TestAttempt, UserBadge, ChatMessage } from '../types';
import { mockBadges } from '../data/mockData';

interface AuthContextType {
  user: User | null;
  userProgress: UserCourseProgress[];
  testAttempts: TestAttempt[];
  userBadges: UserBadge[];
  chatHistory: ChatMessage[];
  login: (email: string, password: string) => Promise<void>;
  signup: (username: string, email: string, password: string, skillInterests: string[]) => Promise<void>;
  logout: () => void;
  updateProfile: (updates: Partial<User>) => void;
  addCourseProgress: (progress: UserCourseProgress) => void;
  updateCourseProgress: (courseId: string, updates: Partial<UserCourseProgress>) => void;
  addTestAttempt: (attempt: TestAttempt) => void;
  addChatMessage: (message: ChatMessage) => void;
  awardBadge: (badgeId: string) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [userProgress, setUserProgress] = useState<UserCourseProgress[]>([]);
  const [testAttempts, setTestAttempts] = useState<TestAttempt[]>([]);
  const [userBadges, setUserBadges] = useState<UserBadge[]>([]);
  const [chatHistory, setChatHistory] = useState<ChatMessage[]>([]);

  useEffect(() => {
    const savedUser = localStorage.getItem('edumentor_user');
    const savedProgress = localStorage.getItem('edumentor_progress');
    const savedAttempts = localStorage.getItem('edumentor_attempts');
    const savedBadges = localStorage.getItem('edumentor_badges');
    const savedChat = localStorage.getItem('edumentor_chat');

    if (savedUser) {
      const parsed = JSON.parse(savedUser);
      parsed.createdAt = new Date(parsed.createdAt);
      setUser(parsed);
    }
    if (savedProgress) {
      const parsed = JSON.parse(savedProgress);
      setUserProgress(parsed.map((p: any) => ({
        ...p,
        startedAt: new Date(p.startedAt),
        completedAt: p.completedAt ? new Date(p.completedAt) : undefined
      })));
    }
    if (savedAttempts) {
      const parsed = JSON.parse(savedAttempts);
      setTestAttempts(parsed.map((a: any) => ({
        ...a,
        completedAt: new Date(a.completedAt)
      })));
    }
    if (savedBadges) {
      const parsed = JSON.parse(savedBadges);
      setUserBadges(parsed.map((b: any) => ({
        ...b,
        earnedAt: new Date(b.earnedAt)
      })));
    }
    if (savedChat) {
      const parsed = JSON.parse(savedChat);
      setChatHistory(parsed.map((c: any) => ({
        ...c,
        createdAt: new Date(c.createdAt)
      })));
    }
  }, []);

  useEffect(() => {
    if (user) {
      localStorage.setItem('edumentor_user', JSON.stringify(user));
    } else {
      localStorage.removeItem('edumentor_user');
    }
  }, [user]);

  useEffect(() => {
    localStorage.setItem('edumentor_progress', JSON.stringify(userProgress));
  }, [userProgress]);

  useEffect(() => {
    localStorage.setItem('edumentor_attempts', JSON.stringify(testAttempts));
  }, [testAttempts]);

  useEffect(() => {
    localStorage.setItem('edumentor_badges', JSON.stringify(userBadges));
  }, [userBadges]);

  useEffect(() => {
    localStorage.setItem('edumentor_chat', JSON.stringify(chatHistory));
  }, [chatHistory]);

  const login = async (email: string, password: string) => {
    await new Promise(resolve => setTimeout(resolve, 500));

    const savedUsers = localStorage.getItem('edumentor_users');
    const users = savedUsers ? JSON.parse(savedUsers) : [];
    const foundUser = users.find((u: any) => u.email === email && u.password === password);

    if (!foundUser) {
      throw new Error('Invalid credentials');
    }

    const { password: _, ...userWithoutPassword } = foundUser;
    userWithoutPassword.createdAt = new Date(userWithoutPassword.createdAt);
    setUser(userWithoutPassword);
  };

  const signup = async (username: string, email: string, password: string, skillInterests: string[]) => {
    await new Promise(resolve => setTimeout(resolve, 500));

    const savedUsers = localStorage.getItem('edumentor_users');
    const users = savedUsers ? JSON.parse(savedUsers) : [];

    if (users.find((u: any) => u.email === email)) {
      throw new Error('Email already exists');
    }

    const newUser: User & { password: string } = {
      id: `user_${Date.now()}`,
      username,
      email,
      password,
      skillInterests,
      skillLevels: skillInterests.reduce((acc, skill) => {
        acc[skill] = 'beginner';
        return acc;
      }, {} as Record<string, string>),
      preferredPlatforms: [],
      learningBudget: 'both',
      weeklyGoalHours: 5,
      totalPoints: 0,
      currentStreak: 0,
      createdAt: new Date()
    };

    users.push(newUser);
    localStorage.setItem('edumentor_users', JSON.stringify(users));

    const { password: _, ...userWithoutPassword } = newUser;
    setUser(userWithoutPassword);
  };

  const logout = () => {
    setUser(null);
    setUserProgress([]);
    setTestAttempts([]);
    setUserBadges([]);
    setChatHistory([]);
  };

  const updateProfile = (updates: Partial<User>) => {
    if (user) {
      const updatedUser = { ...user, ...updates };
      setUser(updatedUser);

      const savedUsers = localStorage.getItem('edumentor_users');
      if (savedUsers) {
        const users = JSON.parse(savedUsers);
        const index = users.findIndex((u: any) => u.id === user.id);
        if (index !== -1) {
          users[index] = { ...users[index], ...updates };
          localStorage.setItem('edumentor_users', JSON.stringify(users));
        }
      }
    }
  };

  const addCourseProgress = (progress: UserCourseProgress) => {
    setUserProgress(prev => [...prev, progress]);
  };

  const updateCourseProgress = (courseId: string, updates: Partial<UserCourseProgress>) => {
    setUserProgress(prev =>
      prev.map(p => p.courseId === courseId ? { ...p, ...updates } : p)
    );

    if (updates.status === 'completed' && user) {
      const completedCount = userProgress.filter(p => p.status === 'completed').length + 1;

      if (completedCount === 1 && !userBadges.find(b => b.badge.id === 'b1')) {
        awardBadge('b1');
      } else if (completedCount === 5 && !userBadges.find(b => b.badge.id === 'b2')) {
        awardBadge('b2');
      } else if (completedCount === 10 && !userBadges.find(b => b.badge.id === 'b3')) {
        awardBadge('b3');
      }
    }
  };

  const addTestAttempt = (attempt: TestAttempt) => {
    setTestAttempts(prev => [...prev, attempt]);

    if (user && attempt.percentage === 100 && !userBadges.find(b => b.badge.id === 'b8')) {
      awardBadge('b8');
    }

    const highScores = [...testAttempts, attempt].filter(a => a.percentage >= 90);
    if (highScores.length >= 5 && !userBadges.find(b => b.badge.id === 'b4')) {
      awardBadge('b4');
    }
  };

  const addChatMessage = (message: ChatMessage) => {
    setChatHistory(prev => [...prev, message]);
  };

  const awardBadge = (badgeId: string) => {
    const badge = mockBadges.find(b => b.id === badgeId);
    if (!badge || userBadges.find(ub => ub.badge.id === badgeId)) return;

    const newUserBadge: UserBadge = {
      id: `ub_${Date.now()}`,
      userId: user!.id,
      badge,
      earnedAt: new Date()
    };

    setUserBadges(prev => [...prev, newUserBadge]);

    if (user) {
      updateProfile({ totalPoints: user.totalPoints + badge.pointsValue });
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        userProgress,
        testAttempts,
        userBadges,
        chatHistory,
        login,
        signup,
        logout,
        updateProfile,
        addCourseProgress,
        updateCourseProgress,
        addTestAttempt,
        addChatMessage,
        awardBadge
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within AuthProvider');
  }
  return context;
}
